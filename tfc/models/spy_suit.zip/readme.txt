Just extract into your models/player/spy directory and it should be ok. Make sure you have old models turned on.

http://supersumo.hopto.org