Extract into your halflife/tfc directory. It *should* extract into the correct folder, but you need "use folder names" checked in the extract dialog box.
AGT-SuperSumo