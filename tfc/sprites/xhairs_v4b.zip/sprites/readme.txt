Extract into your halflife/tfc directory. It *should* extract into the correct folder, but you need "use folder names" checked in the extract dialog box.

These crosshairs are based off my version 4 crosshairs. I made them because steam makes crosshairs blurry. All I did was fatten up the crosshairs a little bit to make them stand out more. The edges are still a little blurry, but it is much better than before.
AGT-SuperSumo