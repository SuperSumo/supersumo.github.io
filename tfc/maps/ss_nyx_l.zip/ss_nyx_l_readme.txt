/---------------------\
| General Information |
\---------------------/

Title		: ss_nyx_l
Filename	: ss_nyx_l.bsp
Author		: Daniel "SuperSumo" Gleason
Author Email	: SuperSumoZ@Yahoo.com
Home page	: http://supersumo.hopto.org
Description	: A Capture The Flag/Defend The Flag map. I made it
		  for 9v9, but you can play it however you like. 10
		  team points are given if the offense captures the
		  flag, and 5 team points are given if the defense
		  holds the flag for 5 minutes untouched. In case you
		  were wondering, nyx is the greek goddess of night.

/--------------------\
| Credits and Thanks |
\--------------------/

Clan AGT, for letting me play with them for 2 years now. I got input
and support from most of the members on this map, and it helped me to
finish it.

WildBillGates, for playing with me since I started. It's been a blast
playing with you for over 3 years.

Danger, for helping me when I was a wee mapping n00b. He showed me
how to do a lot of stuff, and he must have been annoyed at all the
questions. :)

FryGuy. Sheesh man. He helped me so much in the creation of this map
it's crazy. Especially with the "hold the flag for points" part.

Concite, for making the overview of my map. I totally forgot to make
one. Thanks.

All the people at #tfmapped. They helped me with the little, annoying
bugs that popped up when I didn't know what I was doing. Thanks.

/------------------\
| Play Information |
\------------------/

Deathmatch	: Yes, Teamplay -> TFC
Single Player	: No
Map Description	: Two bases, red and blue. Separated by a pit.
How Many Players: 6v6 and up would be a good range I think.

/-----------------\
| Map Information |
\-----------------/

New Textures	: Yes. My face, my "thank you" wall, and six hidden
		  sumos.
New Sounds	: No.

/--------------\
| Construction |
\--------------/

Base		: All from scratch except the steam coming from the
		  pipe under the flag. I used a tutorial for that. :)
Editor(s) used	: Hammer (Worldcraft) v3.4
Compile Machine	: Athlon 1.2 with 512 megs pc2100 ddr ram.
Compile time	: 1 hour, 50 minutes, 54 seconds.
Design time	: About 6 months, with long breaks.

/---------------------------\
| Installation Instructions |
\---------------------------/

Unzip the files in this archive into your half-life/tfc directory.
There are 7 files included in the zip.

ss_nyx_l.bsp - goes in halflife/tfc/maps
ss_nyx_l.txt - goes in halflife/tfc/maps
grenade_bag.spr - goes in halflife/tfc/sprites
ss_nyx_l.bmp - goes in halflife/tfc/overviews
ss_nyx_l.tga - goes in halflife/tfc/overviews
ss_nyx_l.txt - goes in halflife/tfc/overviews
ss_nyx_l_readme.txt (this file)

/-------------\
| Compile Log |
\-------------/

hlcsg v2.5.3 rel (May  2 2001)
Based on Valve's version, modified with permission.
Submit detailed bug reports to (zoner@gearboxsoftware.com)
-----  BEGIN  hlcsg -----
Command line: "D:\Utilities\zoners tools\hlcsg.exe"-wadinclude sumo.wad D:\_Daniel\Maps\TFC\ss_nyx_l.map 

-= Current hlcsg Settings =-
Name                 |  Setting  |  Default
---------------------|-----------|-------------------------
threads               [       1 ] [  Varies ]
verbose               [     off ] [     off ]
log                   [      on ] [      on ]
developer             [       0 ] [       0 ]
chart                 [     off ] [     off ]
estimate              [     off ] [     off ]
max texture memory    [ 4194304 ] [ 4194304 ]
priority              [  Normal ] [  Normal ]

noclip                [     off ] [     off ]
onlyents              [     off ] [     off ]
wadtextures           [      on ] [      on ]
skyclip               [      on ] [      on ]
hullfile              [    None ] [    None ]
min surface area      [   0.500 ] [   0.500 ]
brush union threshold [   0.000 ] [   0.000 ]

Wadinclude list :
[zhlt.wad]
[sumo.wad]


entering D:\_Daniel\Maps\TFC\ss_nyx_l.map
CreateBrush:
 (50.00 seconds)
SetModelCenters:
 (0.00 seconds)
CSGBrush:
 (8.91 seconds)
Using WAD File: \half-life\tfc\tfc.wad
Using WAD File: \half-life\tfc\tfc2.wad
Embedding textures from WAD File [\half-life\tfc\sumo.wad] into BSP
Using WAD File: \half-life\valve\liquids.wad
Using WAD File: \half-life\valve\halflife.wad
added 15 additional animating textures.
Texture usage is at 1.94 mb (of 4.00 mb MAX)
61.01 seconds elapsed [1m 1s]

-----   END   hlcsg -----



hlbsp v2.5.3 rel (May  2 2001)
Based on Valve's version, modified with permission.
Submit detailed bug reports to (zoner@gearboxsoftware.com)
-----  BEGIN  hlbsp -----
Command line: "D:\Utilities\zoners tools\hlbsp.exe"D:\_Daniel\Maps\TFC\ss_nyx_l.map 

-= Current hlbsp Settings =-
Name               |  Setting  |  Default
-------------------|-----------|-------------------------
threads             [       1 ] [  Varies ]
verbose             [     off ] [     off ]
log                 [      on ] [      on ]
developer           [       0 ] [       0 ]
chart               [     off ] [     off ]
estimate            [     off ] [     off ]
max texture memory  [ 4194304 ] [ 4194304 ]
priority            [  Normal ] [  Normal ]

noclip              [     off ] [     off ]
nofill              [     off ] [     off ]
notjunc             [     off ] [     off ]
subdivide size      [     240 ] [     240 ] (Min 64) (Max 240)
max node size       [    1024 ] [    1024 ] (Min 64) (Max 4096)


BSP generation successful, writing portal file 'D:\_Daniel\Maps\TFC\ss_nyx_l.prt'
25.10 seconds elapsed

-----   END   hlbsp -----



hlvis v2.5.3 rel (May  2 2001)
Based on Valve's version, modified with permission.
Submit detailed bug reports to (zoner@gearboxsoftware.com)
-----  BEGIN  hlvis -----
Command line: "D:\Utilities\zoners tools\hlvis.exe"-full D:\_Daniel\Maps\TFC\ss_nyx_l.map 

-= Current hlvis Settings =-
Name               |  Setting  |  Default
-------------------|-----------|-------------------------
threads             [       1 ] [  Varies ]
verbose             [     off ] [     off ]
log                 [      on ] [      on ]
developer           [       0 ] [       0 ]
chart               [     off ] [     off ]
estimate            [     off ] [     off ]
max texture memory  [ 4194304 ] [ 4194304 ]
priority            [  Normal ] [  Normal ]

fast vis            [     off ] [     off ]
full vis            [      on ] [     off ]


1898 portalleafs
4942 numportals
BasePortalVis:
 (38.38 seconds)
LeafThread:
 (103.90 seconds)
average leafs visible: 87
g_visdatasize:69388  compressed from 451724
142.65 seconds elapsed [2m 22s]

-----   END   hlvis -----



hlrad v2.5.3 rel (May  2 2001)
Based on Valve's version, modified with permission.
Submit detailed bug reports to (zoner@gearboxsoftware.com)
-----  BEGIN  hlrad -----
Command line: "D:\Utilities\zoners tools\hlrad.exe"-extra -sparse -bounce 6 -smooth 50 -chop 64 -texchop 32 -coring 1 -dscale 1 -fade 1 -maxlight 220 -sky 1 D:\_Daniel\Maps\TFC\ss_nyx_l.map 

-= Current hlrad Settings =-
Name                | Setting             | Default
--------------------|---------------------|-------------------------
threads              [                 1 ] [            Varies ]
verbose              [               off ] [               off ]
log                  [                on ] [                on ]
developer            [                 0 ] [                 0 ]
chart                [               off ] [               off ]
estimate             [               off ] [               off ]
max texture memory   [           4194304 ] [           4194304 ]
priority             [            Normal ] [            Normal ]

vismatrix algorithm  [            Sparse ] [          Original ]
oversampling (-extra)[                on ] [               off ]
bounces              [                 6 ] [                 1 ]
ambient light        [ 0.000 0.000 0.000 ] [ 0.000 0.000 0.000 ]
maximum light        [         28160.000 ] [           256.000 ]
circus mode          [               off ] [               off ]

smoothing threshold  [            50.000 ] [            50.000 ]
direct threshold     [            25.000 ] [            25.000 ]
direct light scale   [             1.000 ] [             2.000 ]
coring threshold     [             1.000 ] [             1.000 ]
patch interpolation  [                on ] [                on ]

texscale             [                on ] [                on ]
patch subdividing    [                on ] [                on ]
chop value           [            64.000 ] [            64.000 ]
texchop value        [            32.000 ] [            32.000 ]

global fade          [             1.000 ] [             1.000 ]
global falloff       [                 2 ] [                 2 ]
global light scale   [             1.000 ] [             1.000 ]
global gamma amount  [             0.500 ] [             0.500 ]
global sky diffusion [             1.000 ] [             1.000 ]

opaque entities      [                on ] [                on ]
sky lighting fix     [                on ] [                on ]
incremental          [               off ] [               off ]
dump                 [               off ] [               off ]


[Reading texlights from 'D:\Utilities\zoners tools\lights.rad']
[49 texlights parsed from 'D:\Utilities\zoners tools\lights.rad']

11240 faces
Create Patches : 64209 base patches
0 opaque faces
923645 square feet [133004880.00 square inches]
8924 direct lights

BuildFacelights:
 (4611.94 seconds)
BuildVisLeafs:
 (756.51 seconds)
visibility matrix   :  15.2 megs
MakeScales:
 (1147.25 seconds)
SwapTransfers:
 (25.23 seconds)
Transfer Lists : 39643180 transfers
       Indices : 20214924 bytes
          Data : 158572720 bytes
GatherLight:
 (3.08 seconds)
GatherLight:
 (3.07 seconds)
GatherLight:
 (3.06 seconds)
GatherLight:
 (3.06 seconds)
GatherLight:
 (3.06 seconds)
GatherLight:
 (3.05 seconds)
FinalLightFace:
 (77.94 seconds)
6654.59 seconds elapsed [1h 50m 54s]

-----   END   hlrad -----

/-----------------------\
| Copyright-Permissions |
\-----------------------/

ss_nyx_l is Copyright 2002 by Daniel "SuperSumo" Gleason.
All Rights Reserved.

You can use ideas from my map, but I would like it if you emailed me
about them, cause I would like to see how they came out. :)

If you distribute my map, please include this file also.