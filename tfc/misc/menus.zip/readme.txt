Four easy steps to installing these menus.

1. Install the font into your OS. Go to control panel, fonts, install new fonts. Browse to XBand Rough.TTF, click on it, and click ok.
2. Go to Half-Life\valve\gfx\vgui\fonts and delete (or move to another folder) all the ones that start with 1024.
3. Put the 1024_textscheme.txt into your halflife\tfc directory.
4. Enjoy awesome menus.

Much thanks to draglines awesome tutorials. Dragline's site: http://home.earthlink.net/~dragcity/
Also thanks to the people that made the "XBAND Rough" and "Verdana" fonts.

-SuperSumo
http://supersumo.hopto.org